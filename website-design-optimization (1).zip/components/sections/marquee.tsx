import { Flame } from "lucide-react"
import { cn } from "@/lib/utils"

const DEFAULT_WORDS = ["بيتزا", "برجر", "موهيتو", "كيك", "كالزوني", "سموثي", "آيس كريم", "قشطوطة"]

const TONES = {
  forest: { wrap: "bg-forest text-cream", icon: "text-neon/80" },
  copper: { wrap: "bg-copper text-ink", icon: "text-cream" },
}

export function Marquee({
  words = DEFAULT_WORDS,
  tone = "forest",
  reverse = false,
}: {
  words?: string[]
  tone?: keyof typeof TONES
  reverse?: boolean
}) {
  const row = [...words, ...words]
  const colors = TONES[tone]

  return (
    <div aria-hidden="true" className={cn("overflow-hidden py-4", colors.wrap)}>
      <div dir="ltr" className={cn("animate-marquee flex w-max", reverse && "[animation-direction:reverse]")}>
        {[0, 1].map((copy) => (
          <div key={copy} className="flex shrink-0 items-center">
            {row.map((word, i) => (
              <span key={`${copy}-${i}`} className="flex items-center gap-7 px-7 font-display text-2xl font-bold md:text-4xl">
                {word}
                <Flame className={cn("size-5 md:size-6", colors.icon)} />
              </span>
            ))}
          </div>
        ))}
      </div>
    </div>
  )
}
