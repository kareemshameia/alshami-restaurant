import { BrandLockup } from "@/components/brand/brand-lockup"
import { HeaderCartButton } from "./header-cart-button"

const NAV = [
  { id: "pizza", label: "البيتزا" },
  { id: "burger", label: "البرجر" },
  { id: "drinks", label: "العصائر" },
  { id: "desserts", label: "الكيك" },
  { id: "menu", label: "المنيو" },
  { id: "contact", label: "تواصل" },
]

export function SiteHeader() {
  return (
    <header className="fixed inset-x-0 top-0 z-50 border-b border-cream/8 bg-ink/80 backdrop-blur-md">
      <div className="mx-auto flex h-16 max-w-6xl items-center justify-between gap-4 px-5 md:px-8">
        <a href="#top" aria-label="الشامي — العودة للأعلى" className="rounded-2xl">
          <BrandLockup />
        </a>

        <nav aria-label="التنقل الرئيسي" className="hidden lg:block">
          <ul className="flex items-center gap-8 text-[15px] text-cream/70">
            {NAV.map((item) => (
              <li key={item.id}>
                <a href={`#${item.id}`} className="transition-colors duration-300 hover:text-cream">
                  {item.label}
                </a>
              </li>
            ))}
          </ul>
        </nav>

        <div className="flex items-center gap-2">
          <a
            href="#menu"
            className="flex h-10 items-center rounded-full bg-copper px-5 text-sm font-semibold text-ink transition-transform duration-300 ease-out-expo active:scale-95 md:hover:-translate-y-0.5"
          >
            اطلب الآن
          </a>
          <HeaderCartButton />
        </div>
      </div>
      <div aria-hidden="true" className="scroll-progress absolute inset-x-0 bottom-0 h-px bg-neon/70" />
    </header>
  )
}
